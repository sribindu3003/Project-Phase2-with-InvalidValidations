﻿using carbal;
using carentities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using carexceptions;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for GetAllCars.xaml
    /// </summary>
    public partial class GetAllCars : Window
    {
        public GetAllCars()
        {
            InitializeComponent();
        }


        private void BtnSearchCarsByType_Click(object sender, RoutedEventArgs e)
        {
            string ManufacturerName;
            string Type;
            List<Car> objcars = null;
            try
            {
                if (cmbname.Text != "" && cmbtype.Text != "")
                {
                    ManufacturerName = cmbname.Text;
                    Type = cmbtype.Text;
                    objcars = CarBal.SearchCarByNameBal(ManufacturerName,Type);
                    
                    if (objcars != null)
                    {
                        dgList.ItemsSource = objcars;
                    }
                    else
                        MessageBox.Show("Car not found");
                }
                else
                {
                    MessageBox.Show("Please Enter ManufacturerName and Type to Search");
                }
            }

            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnGetAllCars_Click_1(object sender, RoutedEventArgs e)
        {
            List<Car> objcars = CarBal.GetListBal();
            dgList.ItemsSource = objcars;
        }

        private void BtnHomePage_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Show();
        }
    }
}
