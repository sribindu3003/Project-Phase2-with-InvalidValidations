﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using carbal;
using carentities;
using carexceptions;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for SearchCar.xaml
    /// </summary>
    public partial class SearchCarByModel : Window
    {
        public SearchCarByModel()
        {
            InitializeComponent();
        }

        private void BtnSearchCarDetails_Click(object sender, RoutedEventArgs e)
        {
            FindCar();
        }
        private void FindCar()
        {

            try
            {
                string model;
                Car objCar;
                model = txtModel.Text;
                objCar = CarBal.SearchCarByModelBal(model);
                if (objCar != null)
                {
                    cmbManufacturerName.Text = objCar.ManufacturerName.ToString();
                    cmbCarType.Text = objCar.Type.ToString();
                    txtEngine.Text = objCar.Engine;
                    txtBHP.Text = objCar.BHP.ToString();
                    cmbTransmissionType.Text = objCar.Transmission.ToString();
                    txtMileage.Text = objCar.Mileage.ToString();
                    txtSeats.Text = objCar.Seats.ToString();
                    txtAirbags.Text = objCar.AirBagDetails;
                    txtBootSpace.Text = objCar.BootSpace.ToString();
                    txtPrice.Text = objCar.Price.ToString();
                }
                else
                {
                    MessageBox.Show("Car with given model couldn't be found.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
