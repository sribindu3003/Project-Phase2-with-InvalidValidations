﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using carbal;
using carentities;
using carexceptions;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for DeleteCar.xaml
    /// </summary>
    public partial class DeleteCar : Window
    {
        public DeleteCar()
        {
            InitializeComponent();
        }

        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            Administrator adm = new Administrator();
            adm.Show();
            this.Show();
        }

        private void BtnDeleteCar_Click(object sender, RoutedEventArgs e)
        {
            RemoveCar();
        }

        private void RemoveCar()
        {
            try
            {
                string Model;
                //
                bool CarDeleted;
                //
                Model = txtModel.Text;
                //
                CarDeleted = CarBal.DeleteCarBal(Model);
                if (CarDeleted == true)
                {
                    MessageBox.Show("Car Details deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Car Details couldn't be deleted.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
