﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carentities
{
    public class Car
    {
        public string ManufacturerName { get; set; }
        public string Model { get; set; }
        public string Type { get; set; }
        public string Engine { get; set; }
        public int BHP { get; set; }
        public string Transmission { get; set; }
        public int Mileage { get; set; }
        public int Seats { get; set; }
        public string AirBagDetails { get; set; }
        public int BootSpace { get; set; }
        public double Price { get; set; }
    }
}
